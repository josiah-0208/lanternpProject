package model;

public class BoardLikes {
	
	private int likes_no;
	private int review_no;
	private int member_no;
	
	public int getLikes_no() {
		return likes_no;
	}
	public void setLikes_no(int likes_no) {
		this.likes_no = likes_no;
	}
	public int getReview_no() {
		return review_no;
	}
	public void setReview_no(int review_no) {
		this.review_no = review_no;
	}
	public int getMember_no() {
		return member_no;
	}
	public void setMember_no(int member_no) {
		this.member_no = member_no;
	}
	
}
